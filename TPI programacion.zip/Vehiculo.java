public class Vehiculo {
    private String patente;
    private String marca;
    private String modelo;
    private int año;

    // Constructor para inicializar el vehiculo
    public Vehiculo(String patente, String marca, String modelo, int año) {
        this.patente = patente; 
        this.marca = marca; 
        this.modelo = modelo;
        this.año = año;
    }

    public String getPatente() {
        return patente; 
    }

    public String getMarca() {
        return marca; 
    }

    public String getModelo() {
        return modelo; 
    }

    public int getAño() {
        return año;
    }

    // Muestra los datos de forma simple
    public void mostrarDatos() {
        System.out.println("Datos del Vehiculo");
        System.out.println("Patente: ");
        System.out.println(patente);
        System.out.println("Marca: ");
        System.out.println(marca);
        System.out.println("Modelo: ");
        System.out.println(modelo);
        System.out.println("Año:  ");
        System.out.println(año);
    }
}
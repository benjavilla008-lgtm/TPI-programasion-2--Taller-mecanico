public class Repuesto {
    private String nombre;
    private double precio;

    public Repuesto(String nombre, double precio) {
        this.nombre = nombre;
        this.precio = precio;
    }
    public String getNombre() {
        return nombre;
    }
    public double getPrecio() {
        return precio;
    }
    public void mostrarDatos() {
        System.out.println("Repuesto: ");
        System.out.println(nombre);
        System.out.println("Precio: ");
        System.out.println(precio);
    }
}
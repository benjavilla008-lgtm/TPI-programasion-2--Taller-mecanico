import java.util.ArrayList;

public class Taller {
    private String nombre;
    private ArrayList<Cliente> clientes;
    private ArrayList<Mecanico> mecanicos;
    private ArrayList<OrdenDeServicio> ordenes;

    public Taller(String nombre) {
        this.nombre = nombre;
        this.clientes = new ArrayList<Cliente>();
        this.mecanicos = new ArrayList<Mecanico>();
        this.ordenes = new ArrayList<OrdenDeServicio>();
    }

    public void agregarCliente(Cliente c) {
        clientes.add(c);
    }

    public void agregarMecanico(Mecanico m) {
        mecanicos.add(m);
    }

    public void agregarOrden(OrdenDeServicio o) {
        ordenes.add(o);
    }

    public void mostrarClientes() {
        System.out.println("Clientes en taller");
        for (int i = 0; i < clientes.size(); i = i + 1) {
            Cliente c = clientes.get(i);
            String nombreCliente = c.getNombre();
            System.out.println(nombreCliente);
        }
    }

    public void mostrarMecanicos() {
        System.out.println("Mecanico en taller");
        for (int i = 0; i < mecanicos.size(); i = i + 1) {
            Mecanico m = mecanicos.get(i);
            m.mostrarDatos();
        }
    }
}
import java.util.ArrayList;

public class OrdenDeServicio {
    private int numeroOrden;
    private Vehiculo vehiculo;
    private Mecanico mecanico;
    private double costoManoDeObra;
    private ArrayList<Repuesto> repuestos;
    private String estado;

    public OrdenDeServicio(int numeroOrden, Vehiculo vehiculo, Mecanico mecanico, double costoManoDeObra) {
        this.numeroOrden = numeroOrden;
        this.vehiculo = vehiculo;
        this.mecanico = mecanico;
        this.costoManoDeObra = costoManoDeObra;
        this.repuestos = new ArrayList<Repuesto>();
        this.estado = "En Proceso";
        
        // El mecanico pasa a estar ocupado
        mecanico.ocupar();
    }

    public void agregarRepuesto(Repuesto r) {
        repuestos.add(r);
        System.out.println("Repuesto agregado a la orden.");
    }

    public double calcularTotal() {
        double total = costoManoDeObra;
        
        for (int i = 0; i < repuestos.size(); i = i + 1) {
            Repuesto r = repuestos.get(i);
            double precioRepuesto = r.getPrecio();
            total = total + precioRepuesto;
        }
        
        return total;
    }

    public void finalizarTrabajo() {
        estado = "Finalizado";
        mecanico.liberar();
        System.out.println("orden finalizada");
    }

    public void mostrarResumen() {
        System.out.println("");
        System.out.println("orden numero:");
        System.out.println(numeroOrden);
        System.out.println("Estado de la orden:");
        System.out.println(estado);
        
        // Muestra vehiculo y mecanico
        vehiculo.mostrarDatos();
        mecanico.mostrarDatos();
        
        double totalPagar = calcularTotal();
        System.out.println("Monto Total a Pagar:");
        System.out.println(totalPagar);
        System.out.println("");
    }
}
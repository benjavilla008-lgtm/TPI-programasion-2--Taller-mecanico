public class Mecanico {
    private String nombre;
    private String especialidad;
    private boolean ocupado;

    public Mecanico(String nombre, String especialidad) {
        this.nombre = nombre;
        this.especialidad = especialidad;
        this.ocupado = false;
    }

    public String getNombre() {
        return nombre;
    }

    public boolean getOcupado() {
        return ocupado;
    }

    public void ocupar() {
        ocupado = true;
    }

    public void liberar() {
        ocupado = false;
    }

    public void mostrarDatos() {
        System.out.println("Datos del Mecanico");
        System.out.println("nombre: ");
        System.out.println(nombre);
        System.out.println("Especialidad: ");
        System.out.println(especialidad);
    }
}
import java.util.ArrayList;

public class Cliente {
    private String nombre;
    private String dni;
    private String telefono;
    private ArrayList<Vehiculo> vehiculos;

    public Cliente(String nombre, String dni, String telefono) {
        this.nombre = nombre;
        this.dni = dni;
        this.telefono = telefono;
        this.vehiculos = new ArrayList<Vehiculo>();
    }

    public String getNombre() {
        return nombre;
    }

    public String getDni() {
        return dni;
    }

    public void agregarVehiculo(Vehiculo miVehiculo) {
        vehiculos.add(miVehiculo);
        System.out.println("Vehiculo cargado");
    }

    public void mostrarVehiculos() {
        System.out.println("Lista de vehiculos");
        
        for (int i = 0; i < vehiculos.size(); i = i + 1) {
            Vehiculo v = vehiculos.get(i);
            v.mostrarDatos();
        }
    }
}